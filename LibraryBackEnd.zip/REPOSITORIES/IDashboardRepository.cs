﻿using $safeprojectname$.Models.DashBoard;
using $safeprojectname$.Models.NameAndIdDTO;

namespace $safeprojectname$.Repositories
{
    public interface IDashboardRepository : IGenericRepository<DashBoardSalesInfo>
    {
        Task<IEnumerable<SalesChartInfo>> GetSalesChartInfo(string sqlQuery);
        Task<IEnumerable<TopBooksChartInfo>> GetTopBooksChartInfo(string sqlQuery);
        Task<IEnumerable<Name_Id_DTO>> GetTopThreeEmployees(string sqlQuery);
    }
}
