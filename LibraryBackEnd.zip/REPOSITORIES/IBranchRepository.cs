﻿using $safeprojectname$.Models.Branch;
using $safeprojectname$.Models.NameAndIdDTO;
using Microsoft.AspNetCore.Mvc;

namespace $safeprojectname$.Repositories
{
    public interface IBranchRepository : IGenericRepository<Branch>
    {
        Task<List<Name_Id_DTO>> GetBookIdsAndNames(string query);
        Task<List<int>> GetBranchesIdsAsync(string query);
        Task<List<BranchLocationDTO>> GetBranchLocationsAsync(string query);
        Task<List<string>> GetBranchNamesAsync(string query);
    }
}
