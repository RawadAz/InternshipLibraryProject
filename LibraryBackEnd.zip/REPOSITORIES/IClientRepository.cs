﻿using $safeprojectname$.Models.Book;
using $safeprojectname$.Models.Book.DTO_s;
using $safeprojectname$.Models.Client;

namespace $safeprojectname$.Repositories
{
    public interface IClientRepository : IGenericRepository<Client>
    {
        Task<List<int>?> GetAllClientIds(string query);
        Task<List<string>> GetAllClientsPhoneNumbers(string query);
        Task<List<RentedBookDTO>?> GetClientRentedBooks(string query);
    }
}
