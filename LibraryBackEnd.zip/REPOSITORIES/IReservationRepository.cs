﻿using $safeprojectname$.Models.Reservation.DTO_s;

namespace $safeprojectname$.Repositories
{
    public interface IReservationRepository : IGenericRepository<ReservationDTO>
    {

    }
}
