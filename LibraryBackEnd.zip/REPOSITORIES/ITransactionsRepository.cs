﻿
using $safeprojectname$.Models.Transactions.DTO_s;

namespace $safeprojectname$.Repositories
{
    public interface ITransactionsRepository : IGenericRepository<TransactionsDTO>
    {
        Task<List<EmployeeSalesDTO>> getAllEmployeeSales(string query);
        Task<List<BookReturnDTO>> getBookReturnDates(string query);
        Task<List<TopSellingBookDTO>> getTopSellingBooks(string query);
    }
}
