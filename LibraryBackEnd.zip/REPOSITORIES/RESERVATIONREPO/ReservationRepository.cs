﻿using Dapper;
using $safeprojectname$.Data;
using $safeprojectname$.Models.Reservation.DTO_s;
using $safeprojectname$.Repositories.ClientRepo;
using $safeprojectname$.Repositories.EventRepo;
using $safeprojectname$.Repositories.GenericRepo;
using System.Threading.Tasks;

namespace $safeprojectname$.Repositories.ReservationRepo
{
    public class ReservationRepository : GenericRepository<ReservationDTO>, IReservationRepository
    {
        private new readonly LibraryDBConnection _Connection;

        public IGenericRepository<ReservationDTO> GenericRepository { get; private set; }

        public ReservationRepository(LibraryDBConnection connection) : base(connection)
        {
            _Connection = connection;
            GenericRepository = new GenericRepository<ReservationDTO>(_Connection);
            
        }

    }
}
