﻿using $safeprojectname$.Models.Employee;

namespace $safeprojectname$.Configurations.JwtUtils
{
    public interface IJwtUtils
    {
        public string GenerateJwtToken(string username, LoginInfoDTO loginInfo);
    }
}
