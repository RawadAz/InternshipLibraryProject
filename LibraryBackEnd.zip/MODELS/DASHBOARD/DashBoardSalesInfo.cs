﻿namespace $safeprojectname$.Models.DashBoard
{
    public class DashBoardSalesInfo
    {
        public double Total_Revenue { get; set; }
        public int Total_sales { get; set; }
        public int Books_Sold { get; set; }
        public int Books_rented { get; set; }
        public int Rented_Now { get; set; }
    }
}
