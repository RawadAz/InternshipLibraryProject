﻿namespace $safeprojectname$.Models.DashBoard
{
    public class TopBooksChartInfo
    {
        public string Name { get; set; } = string.Empty;
        public int Sold_Books { get; set; }
    }
}
