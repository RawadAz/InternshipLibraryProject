﻿namespace $safeprojectname$.Models.Branch
{
    public class BranchLocationDTO
    {
        public string Branch_Name { get; set; } = string.Empty; 
        public string Location { get; set; } = string.Empty;
    }
}
