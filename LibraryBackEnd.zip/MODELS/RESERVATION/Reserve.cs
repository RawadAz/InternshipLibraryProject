﻿namespace $safeprojectname$.Models.Reservation
{
    public class Reserve
    {
        public int Event_Id { get; set; }
        public int Client_Id { get; set; }
        public int Nb_Of_Tickets { get; set; }
    }
}
