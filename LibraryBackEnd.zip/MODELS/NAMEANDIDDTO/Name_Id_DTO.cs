﻿namespace $safeprojectname$.Models.NameAndIdDTO
{
    public class Name_Id_DTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
